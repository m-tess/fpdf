<?php
/**********************************************************/
/**********************************************************/
/******************  Les donnees a remplacer    **********/
/**********************************************************/
/**********************************************************/


$image='Logo.jpg';


/**********************************************************/
/**********************************************************/
/******************  fin  data  *******************************/
/**********************************************************/
/**********************************************************/
require('WriteTag.php');

class PDF extends PDF_WriteTag
{

function getPageNumber(){return $this->PageNo();}

}

$pdf=new PDF();
$pdf->AddPage();
$pdf->AliasNbPages();
$pdf->SetMargins(15,15,15);
$pdf->SetFont('Times','B',12);
// Feuille de style
$pdf->SetStyle("p","Times","N",12,"0,0,0",0);
$pdf->SetStyle("p1","Times","N",12,"0,0,0",10);
$pdf->SetStyle("vb","Times","B",0,"0,0,0");

$pdf->Ln();

$pdf->Image($image,68,10,68);
// Titre

$pdf->Ln(35);
$pdf->SetFont('Ubuntu','b',14);
$pdf->Cell(167,5,"EXCLUSION DE RESPONSABILIT�",0,1,'C');

$pdf->Ln(2);
$text ="<p><vb>JE, ...</vb></p>";
$text .="<p>Demeurant et domicili�(e) � � </p>";
$text .="<p>Agissant en qualit� d��tudiant(e) de l�Universit� Q,</p>";
$text .="<p>Identifi�(e) par mon NIF ou ma CIN au no: ...</p>";
$text .="<p>Ayant pris connaissance du protocole sanitaire �labor� par l�Universit�  Q ;</p>";
$text .="<p>Conscient des risques inh�rents � la fr�quentation d�un espace public et de la possibilit� d��tre contamin�(e) par le virus de la COVID-19 ;</p>";
$text .="<p><vb>M�ENGAGE</vb> formellement � ne pas fr�quenter le campus si je</p>";
$text .="<p1>1) Pr�sente un des sympt�mes suivants : une temp�rature �gale ou sup�rieure � 38�C, une toux persistante, un essoufflement ou des difficult�s respiratoires, la naus�e, des vomissements, des frissons, une perte de go�t ou d�odorat ;</p1>";
$text .="<p1>2) Pr�sente deux des sympt�mes suivants : courbatures, maux de t�te, irritation de la gorge, �coulement ou congestion nasaux ;</p1>";
$text .="<p1>3) Ai conscience d�avoir �t� en contact avec une personne ayant �t� diagnostiqu�e positive pour la COVID-19 ou ayant pr�sent� les sympt�mes pr�c�dents ;</p1>";
$text .="<p><vb>ACCEPTE</vb> d�ores et d�j� que toute manifestation des sympt�mes pr�c�dents autorise l�Universit�  Q � m�interdire l�entr�e du campus ou � me placer en quarantaine en attendant ma prise en charge m�dicale ;</p>";
$text .="<p><vb>M�ENGAGE</vb> � me conformer au protocole sanitaire �labor� par l�universit�, conscient(e) que l�irrespect dudit protocole m�expose, � la discr�tion de l�Universit�, � �tre forc�(e) de laisser le campus ;</p>";
$text .="<p><vb>D�CHARGE</vb> l�Universit�  Q de toute responsabilit� pour tout dommage d�coulant d�une �ventuelle contamination par le coronavirus de la COVID-19 ;</p>";
$text .="<p><vb>RENONCE</vb> d�ores et d�j� � toute r�clamation amiable, � toute action en justice tant au civil qu�au p�nal contre l�universit� qui serait motiv�e par une �ventuelle contamination par le coronavirus de la COVID-19.</p>";
$text .="<p>Fait � Port-au-Prince, le ���� septembre 2020</p>";

$pdf->WriteTag(0,7,$text,0,"J",0,3);
$pdf->Ln(15);


//Remarques et signature
$pdf->Cell(169,5,"---------------------------------------",0,1,'R');


$pdf->Output();
?>